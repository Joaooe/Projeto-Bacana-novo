

package Model;

import DAL.GerenciadorBancoDadosCliente;

public class CadastroClienteModel {
    
    private String nomeCliente;
    private String cep;
    private String endereco;
    private String Bairro;
    private String Cidade;
    private String fone;
    private String email;
    private String id;
    private String bairro;
    private String cidade;
    

    public CadastroClienteModel(String nome, String cep, String endereco, String fone, String email) {
        this.nomeCliente = nome;
        this.cep = cep;
        this.endereco = endereco;
          this.Bairro = bairro;
        this.Cidade = cidade;
        this.fone = fone;
        this.email = email;
    }
    
    
    
    public Boolean enviarDadosDbDAL(CadastroClienteModel novoCliente) {

        Boolean sucesso = null;
        GerenciadorBancoDadosCliente novoClient = new GerenciadorBancoDadosCliente();
        sucesso = novoClient.salvarClienteBD(novoClient);
        return sucesso;
    }

   

    
    
    
}
